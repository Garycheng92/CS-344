To compile the code, run "gcc -o smallsh smallsh.c"
To run the program, use "./smallsh"
