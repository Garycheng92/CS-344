Everything on my grading script worked, except for plaintext3 for some reason. I am not sure if this is a problem with the grading script or my program.
If I run the programs manually, it works fine, but for some reason the grading script makes the ciphertext file 0 bytes.

please adjust permissions accordingly.
chmod 777 *
